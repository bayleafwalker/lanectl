#!/usr/bin/env bash
set +e
root=/tmp/hla-inline-upload-acceptance-r3-20261115
cd "$root/source" || exit 90
env -i PATH=/run/current-system/sw/bin:/usr/bin:/bin LANG=C.UTF-8 UV_CACHE_DIR="$root/uv-cache" PYTHONDONTWRITEBYTECODE=1 PLAYWRIGHT_BROWSERS_PATH="$root/missing-native-browser" HLA_ASSERT_DOCKER_ONLY=1 uv run --no-sync python -m pytest -q -p no:cacheprovider --basetemp="$root/pytest-docker-full-final" tests/test_hla1587_acceptance.py --junitxml="$root/docker-full-final-junit.xml"
result=$?
printf '%s\n' "$result" > "$root/docker-full-final.exit"
exit "$result"
