
const work = process.env.WORK_DIR;
const { chromium } = require(work + "/frontend/node_modules/playwright");
const assert = require("node:assert/strict");
const base = process.env.WEB_BASE;
const mode = process.env.CASE_ID;
const aid = "bank_partner_transactions";
const bid = "bank_partner_savings";
const aName = "Bank Partner Transactions";
const bName = "Bank Partner Savings";
const cName = "Bank Partner Overdue";
const result = {case: mode, steps: []};
function step(name, data) { result.steps.push({name, data}); console.log("STEP", name, JSON.stringify(data)); }
async function login(browser, role, options = {}) {
const context = await browser.newContext(options);
const page = await context.newPage();
await page.goto(base + "/login");
await page.fill("#username", "acceptance-" + role);
await page.fill("#password", "local-test-password-123");
await Promise.all([page.waitForURL(url => !url.pathname.startsWith("/login")), page.click("button[type=submit]")]);
return {context, page};
}
async function row(page, name) {
const row = page.getByRole("row").filter({hasText: name});
await row.first().waitFor({state: "attached", timeout: 15000});
assert.equal(await row.count(), 1, "expected exactly one named source row: " + name);
return row;
}
async function href(row) {
const link = row.locator('a[href^="/runs/"]');
assert.equal(await link.count(), 1, "expected exactly one run link in row");
return await link.getAttribute("href");
}
async function prepare(page, name, filename) {
const r = await row(page, name);
const preflight = page.waitForResponse(response => response.url().includes("/dry-run") && response.request().method() === "POST");
await r.locator('input[type="file"]').setInputFiles(work + "/" + filename);
await preflight;
return r;
}
(async () => {
const server = await chromium.launchServer({host: "127.0.0.1", port: 0, headless: true, args: ["--no-sandbox"]});
console.log("OWNED_BROWSER_PID=" + server.process().pid);
const browser = await chromium.connect(server.wsEndpoint());
try {
if (mode === "guard-browser-failure") {
console.log("GUARD_BROWSER_READY");
await new Promise(() => {});
} else if (mode === "guard-fault-rewrite") {
const {context, page} = await login(browser, "admin");
await page.goto(base + "/upload");
const input = require("node:fs").readFileSync(work + "/RP-wrong-id.csv", "utf8");
for (const fault of ["id", "path"]) {
let calls = 0;
await page.route("**/upload/dry-run", async route => {
const real = await route.fetch();
const body = await real.json();
assert.equal(body.preview.ready, true);
assert.equal(body.preview.target.source_asset_id, aid);
assert.equal(body.preview.target.upload_path, "/upload/configured-csv");
if (fault === "id") body.preview.target.source_asset_id = bid;
else body.preview.target.upload_path = "/upload/subscriptions";
calls++;
await route.fulfill({response: real, json: body});
});
const body = await page.evaluate(async ({input, aid}) => {
const form = new FormData();
form.append("file", new File([input], "guard.csv", {type: "text/csv"}));
form.append("upload_path", "/upload/configured-csv");
form.append("source_asset_id", aid);
return await (await fetch("/upload/dry-run", {method: "POST", body: form})).json();
}, {input, aid});
assert.equal(calls, 1);
assert.equal(body.preview.ready, true);
assert.equal(body.preview.target.source_asset_id, fault === "id" ? bid : aid);
assert.equal(body.preview.target.upload_path, fault === "path" ? "/upload/subscriptions" : "/upload/configured-csv");
await page.unroute("**/upload/dry-run");
step("fault-rewrite", fault);
}
await context.close();
} else if (mode === "positive") {
const admin = await login(browser, "admin");
await admin.page.goto(base + "/sources");
const ar = await row(admin.page, aName);
const br = await row(admin.page, bName);
const ah = await href(ar);
const bh = await href(br);
const cr = await row(admin.page, cName);
assert.equal(await href(cr), "/runs/" + process.env.RUN_C);
assert.match(await cr.innerText(), /stale/i);
step("stale-before", {href: await href(cr), text: await cr.innerText()});
step("row-hrefs", {a: ah, b: bh, expectedA: process.env.RUN_A, expectedB: process.env.RUN_B});
assert.equal(ah, "/runs/" + process.env.RUN_A);
assert.equal(bh, "/runs/" + process.env.RUN_B);
await admin.page.goto(base + "/upload");
const form = admin.page.locator('form[action="/upload/configured-csv"]');
await form.locator('select[name="source_asset_id"]').selectOption(aid);
await form.locator('input[name="file"]').setInputFiles(work + "/normal.csv");
const [response] = await Promise.all([admin.page.waitForResponse(r => r.url().includes("/upload/configured-csv") && r.request().method() === "POST"), form.getByRole("button", {name: "Upload file"}).click()]);
step("ordinary-upload", {status: response.status(), location: response.headers().location});
assert.equal(response.status(), 303);
await admin.page.waitForURL(/\/ingest-summary\//);
await admin.context.close();
const reader = await login(browser, "reader");
await reader.page.goto(base + "/sources");
await reader.page.waitForURL(url => url.pathname === "/");
step("reader-url", reader.page.url());
assert.equal(new URL(reader.page.url()).pathname, "/");
await reader.context.close();
const operator = await login(browser, "operator");
await operator.page.goto(base + "/sources");
const text = await operator.page.locator("body").innerText();
step("operator", text);
assert.match(text, /couldn't load|something went wrong/i);
await operator.context.close();
} else if (mode === "RP-nojs") {
const {context, page} = await login(browser, "admin", {javaScriptEnabled: false});
await page.goto(base + "/sources");
assert.equal(new URL(page.url()).pathname, "/sources");
const rawRows = page.locator("tr").filter({hasText: aName});
const rawCount = await rawRows.count();
step("no-js-dom", {rawCount, html: await page.content()});
assert.equal(rawCount, 1, "seeded row absent from raw no-JS DOM; inline behavior unobservable");
const posts = [];
const harmless = [];
await page.route("**/*", async route => {
if (route.request().method() !== "POST") { await route.continue(); return; }
const path = new URL(route.request().url()).pathname;
const changes = /^(\/sources\/|\/ingest\/|\/upload\/)/.test(path) && !path.endsWith("/dry-run");
(changes ? posts : harmless).push(path);
await route.abort();
});
let attempted = 0;
for (const form of await rawRows.locator("form").all()) {
for (const file of await form.locator('input[type="file"]').all()) {
if (await file.isEnabled()) await file.setInputFiles(work + "/RP1.csv");
}
for (const field of await form.locator('input[required]:not([type="file"]):not([type="hidden"])').all()) {
if (await field.isVisible() && await field.isEnabled() && !(await field.inputValue())) await field.fill("synthetic");
}
for (const submit of await form.locator('button:not([type]),button[type="submit"],input[type="submit"]').all()) {
if (await submit.isVisible() && await submit.isEnabled()) { attempted++; await submit.click({timeout: 3000}); }
}
}
await page.waitForTimeout(250);
step("no-js", {rowVisible: await rawRows.isVisible(), attempted, posts, harmless});
assert.deepEqual(posts, [], "native row control attempted mutation without JS preflight");
await context.close();
} else {
const {context, page} = await login(browser, "admin");
await page.goto(base + "/sources");
await page.evaluate(() => {window.__hla1587_marker = "same-page";});
const ar = await row(page, aName);
const br = await row(page, bName);
const beforeA = await href(ar);
const beforeB = await href(br);
const cr = mode === "RP-stale" ? await row(page, cName) : null;
if (cr) {
assert.equal(await href(cr), "/runs/" + process.env.RUN_C);
assert.match(await cr.innerText(), /stale/i);
step("stale-before", {href: await href(cr), text: await cr.innerText()});
}
const namedRow = cr || ar;
const namedName = cr ? cName : aName;
const named = namedRow.getByRole("button", {name: "Upload to " + namedName});
assert.equal(await named.count(), 1, "missing inline upload control on named row");
const requests = [];
page.on("request", request => {
const path = new URL(request.url()).pathname;
if (request.method() === "POST" && /^(\/sources\/|\/ingest\/|\/upload\/)/.test(path) && !path.endsWith("/dry-run")) requests.push(request.url());
});
if (mode === "RP7") {
const disabled = await row(page, "Bank Partner Disabled");
assert.equal(await disabled.locator('input[type="file"]').count(), 0);
assert.equal(await disabled.getByRole("button", {name: /upload/i}).count(), 0);
} else if (mode === "RP10") {
await prepare(page, aName, "aria.csv");
const live = ar.locator('[aria-live]');
assert.ok(await live.count());
const receiptPromise = page.waitForResponse(r => r.url().endsWith("/upload") && r.request().method() === "POST");
await named.click();
const receipt = await (await receiptPromise).json();
assert.equal(typeof receipt.run_id, "string");
assert.ok(receipt.run_id.length > 0 && receipt.run_id.length <= 256);
step("receipt", {runId: receipt.run_id, freshness: receipt.freshness_state ?? null});
await live.getByText(/landed|uploaded/i).waitFor({timeout: 10000});
await page.waitForFunction(id => document.querySelector(`a[href="/runs/${id}"]`), receipt.run_id);
assert.equal(await href(ar), "/runs/" + receipt.run_id);
assert.equal(requests.length, 1);
assert.equal(new URL(requests[0]).pathname, "/sources/" + encodeURIComponent(aid) + "/upload");
} else {
let filename = mode === "RP2-xlsx" ? "unique.xlsx" : mode === "RP2-json" ? "unique.json" : mode === "RP3" ? "invalid.csv" : mode + ".csv";
if (mode === "RP4") filename = "duplicate.csv";
if (mode === "RP5" || mode === "RP5-old-ready") {
const reverse = mode === "RP5-old-ready";
let releaseOld;
let oldSeen;
let oldDone;
const gate = new Promise(resolve => { releaseOld = resolve; });
const seen = new Promise(resolve => { oldSeen = resolve; });
const settled = new Promise(resolve => { oldDone = resolve; });
let oldState = "pending";
let oldError = null;
let first = true;
await page.route("**/sources/**/dry-run", async route => {
if (!first) { await route.continue(); return; }
first = false;
oldSeen();
try {
const real = await route.fetch();
await gate;
await route.fulfill({response: real});
oldState = "delivered";
} catch (error) {
const failure = route.request().failure();
if (failure && /abort|cancel/i.test(failure.errorText)) oldState = "cancelled";
else { oldState = "error"; oldError = String(error); }
} finally { oldDone(); }
});
await ar.locator('input[type="file"]').setInputFiles(work + (reverse ? "/RP5.csv" : "/invalid.csv"));
await seen;
const latestName = reverse ? "invalid.csv" : "RP5.csv";
const latestResponse = page.waitForResponse(response => response.url().includes("/sources/") && response.url().endsWith("/dry-run") && (response.request().postData() || "").includes(latestName));
await ar.locator('input[type="file"]').setInputFiles(work + "/" + latestName);
const latest = await latestResponse;
assert.equal(latest.status(), 200);
const preview = await latest.json();
assert.equal(preview.ready, !reverse);
assert.equal(preview.target.source_asset_id, aid);
assert.equal(preview.target.upload_path, "/upload/configured-csv");
releaseOld();
await settled;
await page.waitForLoadState("networkidle");
step("stale-preflight", {oldState, oldError, latestName, ready: preview.ready});
assert.ok(["delivered", "cancelled"].includes(oldState));
assert.equal(await ar.locator('input[type="file"]').evaluate(input => input.files[0].name), latestName);
if (reverse) assert.ok(await named.isDisabled());
else assert.ok(await named.isEnabled());
} else {
let faults = 0;
if (mode.startsWith("RP-wrong-")) await page.route("**/sources/**/dry-run", async route => {
const real = await route.fetch();
const body = await real.json();
assert.equal(body.ready, true);
assert.equal(body.target.source_asset_id, aid);
assert.equal(body.target.upload_path, "/upload/configured-csv");
if (mode === "RP-wrong-id") body.target.source_asset_id = bid;
else body.target.upload_path = "/upload/subscriptions";
faults++;
await route.fulfill({response: real, json: body});
});
await prepare(page, mode === "RP4" ? bName : mode === "RP-stale" ? cName : aName, filename);
if (mode.startsWith("RP-wrong-")) {
assert.equal(faults, 1);
await page.waitForTimeout(300);
assert.ok(await named.count() === 0 || await named.isDisabled());
assert.equal(requests.length, 0);
}
}
if (mode.startsWith("RP-wrong-") || mode === "RP5-old-ready") {
assert.equal(requests.length, 0);
} else if (mode === "RP3") {
assert.ok(await named.isDisabled());
assert.match(await ar.innerText(), /issue|required|invalid/i);
assert.equal(requests.length, 0);
} else {
const target = mode === "RP4" ? br : mode === "RP-stale" ? cr : ar;
const targetName = mode === "RP4" ? bName : mode === "RP-stale" ? cName : aName;
const button = target.getByRole("button", {name: "Upload to " + targetName});
await button.waitFor({state: "visible"});
if (mode === "RP6") await page.route("**/sources/**/upload", async route => {await new Promise(resolve => setTimeout(resolve, 800)); await route.continue();});
const receiptPromise = page.waitForResponse(r => r.url().endsWith("/upload") && r.request().method() === "POST");
if (mode === "RP6") await button.dblclick();
else await button.click();
const receipt = await (await receiptPromise).json();
assert.equal(typeof receipt.run_id, "string");
assert.ok(receipt.run_id.length > 0 && receipt.run_id.length <= 256);
step("receipt", {runId: receipt.run_id, freshness: receipt.freshness_state ?? null});
await page.waitForFunction(id => document.querySelector(`a[href="/runs/${id}"]`), receipt.run_id);
assert.equal(await href(target), "/runs/" + receipt.run_id);
await page.waitForTimeout(500);
assert.equal(requests.length, 1);
const selectedId = mode === "RP4" ? bid : mode === "RP-stale" ? "bank_partner_overdue" : aid;
assert.equal(new URL(requests[0]).pathname, "/sources/" + encodeURIComponent(selectedId) + "/upload");
assert.equal(new URL(page.url()).pathname, "/sources");
assert.equal(await page.evaluate(() => window.__hla1587_marker), "same-page");
const text = await target.innerText();
if (mode === "RP-stale") {
const labels = {current: /current|fresh/i, overdue: /overdue|stale/i, due_soon: /due.?soon|expected/i, missing_period: /missing/i, parse_failed: /failed|rejected/i};
assert.ok(labels[receipt.freshness_state], "unrecognized observed freshness");
assert.match(text, labels[receipt.freshness_state]);
}
if (mode === "RP4") assert.match(text, /duplicate|already/i);
else {
assert.match(text, /landed|uploaded/i);
if (mode === "RP-stale") assert.equal(await href(ar), beforeA);
else assert.notEqual(await href(ar), beforeA);
assert.equal(await href(br), beforeB);
}
}
}
step("feature-observation", {mode, requests, beforeA, beforeB, url: page.url()});
await context.close();
}
} finally {
await browser.close();
await server.close();
console.log("RESULT", JSON.stringify(result));
}
})().catch(error => {console.error(error.stack || String(error)); process.exit(1);});
