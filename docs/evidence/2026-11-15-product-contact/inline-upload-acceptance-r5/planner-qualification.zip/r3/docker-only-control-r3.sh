#!/usr/bin/env bash
set +e
root=/tmp/hla-inline-upload-acceptance-r3-20261115
cd "$root/source" || exit 90
env -i PATH=/run/current-system/sw/bin:/usr/bin:/bin LANG=C.UTF-8 UV_CACHE_DIR="$root/uv-cache" PYTHONDONTWRITEBYTECODE=1 PLAYWRIGHT_BROWSERS_PATH="$root/missing-native-browser" HLA_ASSERT_DOCKER_ONLY=1 uv run --no-sync python -m pytest -q -p no:cacheprovider --basetemp="$root/pytest-docker-control-r3" tests/test_hla1587_acceptance.py -k 'selected_browser_failure or rp8_rp9 or real_preflight_fault or loaded_overdue_fixture or build_cleanup_handles or receipt_id_guard' --junitxml="$root/docker-control-r3-junit.xml"
result=$?
printf '%s\n' "$result" > "$root/docker-control-r3.exit"
exit "$result"
