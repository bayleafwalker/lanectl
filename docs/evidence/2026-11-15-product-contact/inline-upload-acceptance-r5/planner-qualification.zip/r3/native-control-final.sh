#!/usr/bin/env bash
set +e
root=/tmp/hla-inline-upload-acceptance-r3-20261115
cd "$root/source" || exit 90
hla_loader_path=$(< "$root/native-ld-path.txt")
env -i PATH=/run/current-system/sw/bin:/usr/bin:/bin LANG=C.UTF-8 UV_CACHE_DIR="$root/uv-cache" PYTHONDONTWRITEBYTECODE=1 PLAYWRIGHT_BROWSERS_PATH="$root/native-browsers" LD_LIBRARY_PATH="$hla_loader_path" uv run --no-sync python -m pytest -q -p no:cacheprovider --basetemp="$root/pytest-native-control-final" tests/test_hla1587_acceptance.py -k 'selected_browser_failure or cleanup_noop or rp8_rp9 or real_preflight_fault or loaded_overdue_fixture or build_cleanup_handles or receipt_id_guard or rejected_receipt_context_guard' --junitxml="$root/native-control-final-junit.xml"
result=$?
printf '%s\n' "$result" > "$root/native-control-final.exit"
exit "$result"
