#!/bin/bash
set +e
cd /tmp/hla-inline-upload-acceptance-r2-20261115/source || exit 90
env -i PATH=/run/current-system/sw/bin:/usr/bin:/bin LANG=C.UTF-8 UV_CACHE_DIR=/tmp/hla-inline-upload-acceptance-r2-20261115/uv-cache PYTHONDONTWRITEBYTECODE=1 uv sync --frozen --extra dev
result=$?
printf '%s\n' "$result" > /tmp/hla-inline-upload-acceptance-r2-20261115/uv-sync.exit
exit "$result"
