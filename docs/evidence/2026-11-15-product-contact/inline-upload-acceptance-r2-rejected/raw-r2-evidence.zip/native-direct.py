import importlib.util
import os
from pathlib import Path

root = Path('/tmp/hla-inline-upload-acceptance-r2-20261115')
spec = importlib.util.spec_from_file_location('r2', root / 'tests/test_hla1587_acceptance.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.TRACE_DIR = root
env = module._environment(root / 'native-direct-env', module._port())
env.update(PATH='/projects/dev/homelab-analytics/.tooling/node-v20.20.1-linux-x64/bin:/usr/bin:/bin', PLAYWRIGHT_BROWSERS_PATH=str(root / 'native-browsers'), PLAYWRIGHT_MODULE=str(root / 'source/apps/web/frontend/node_modules/playwright'), LD_LIBRARY_PATH=(root / 'native-ld-path.txt').read_text(), DEBUG='pw:browser')
try:
    module._run_browser(['node', str(root / 'native-direct.js')], env, root / 'native-direct.log', native=True, force_failure=True)
except RuntimeError as exc:
    assert str(exc) == 'forced native browser failure', str(exc)
    print('PASS actual launchServer Chromium survived killed Node and exact owned browser group was cleaned')
else:
    raise AssertionError('forced failure was not raised')
