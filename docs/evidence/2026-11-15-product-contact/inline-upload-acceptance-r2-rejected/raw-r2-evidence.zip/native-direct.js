const { chromium } = require(process.env.PLAYWRIGHT_MODULE);
(async () => {
  const server = await chromium.launchServer({host: "127.0.0.1", port: 0, headless: true, args: ["--no-sandbox"]});
  console.log("OWNED_BROWSER_PID=" + server.process().pid);
  console.log("GUARD_BROWSER_READY");
  await new Promise(() => {});
})().catch(error => {console.error(error); process.exit(1);});
