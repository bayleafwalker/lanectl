#!/usr/bin/env bash
set +e
root=/tmp/hla-inline-upload-acceptance-r2-20261115
cd "$root/source" || exit 90
hla_loader_path=$(< "$root/native-ld-path.txt")
env -i PATH=/run/current-system/sw/bin:/usr/bin:/bin LANG=C.UTF-8 UV_CACHE_DIR="$root/uv-cache" PYTHONDONTWRITEBYTECODE=1 PLAYWRIGHT_BROWSERS_PATH="$root/native-browsers" LD_LIBRARY_PATH="$hla_loader_path" HLA_FORCE_BROWSER_FALLBACK=1 uv run --no-sync python -m pytest -q -p no:cacheprovider --basetemp="$root/pytest-final2-docker" tests/test_hla1587_acceptance.py --junitxml="$root/final2-docker-junit.xml"
result=$?
printf '%s\n' "$result" > "$root/final2-docker.exit"
exit "$result"
