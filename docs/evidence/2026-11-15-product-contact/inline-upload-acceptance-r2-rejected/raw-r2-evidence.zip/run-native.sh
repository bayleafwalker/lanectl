#!/usr/bin/env bash
set +e
root=/tmp/hla-inline-upload-acceptance-r2-20261115
cd "$root/source" || exit 90
hla_loader_path=$(< "$root/native-ld-path.txt")
env -i PATH=/run/current-system/sw/bin:/usr/bin:/bin LANG=C.UTF-8 UV_CACHE_DIR="$root/uv-cache" PYTHONDONTWRITEBYTECODE=1 PLAYWRIGHT_BROWSERS_PATH="$root/native-browsers" LD_LIBRARY_PATH="$hla_loader_path" uv run --no-sync python tests/test_hla1587_acceptance.py --basetemp="$root/pytest-final-native" --junitxml="$root/final-native-junit.xml"
result=$?
printf '%s\n' "$result" > "$root/final-native.exit"
exit "$result"
