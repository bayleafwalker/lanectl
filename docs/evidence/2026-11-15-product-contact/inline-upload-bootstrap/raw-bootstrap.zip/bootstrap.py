import os, sys, subprocess, time, socket, signal, json, pathlib, shutil, hashlib, traceback
D=pathlib.Path('/tmp/hla-inline-upload-acceptance-bootstrap-20261115'); S=D/'source'; data=D/'data'; data.mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not (k.startswith('HOMELAB_ANALYTICS_') or any(x in k.upper() for x in ('TOKEN','SECRET','PASSWORD','CREDENTIAL','KUBECONFIG','DATABASE_URL')))}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(S),HOMELAB_ANALYTICS_DATA_DIR=str(data),HOMELAB_ANALYTICS_IDENTITY_MODE='local',HOMELAB_ANALYTICS_SESSION_SECRET='bootstrap-synthetic-secret-01234567890123456789',HOMELAB_ANALYTICS_API_HOST='127.0.0.1',HOMELAB_ANALYTICS_API_PORT='18743',HOMELAB_ANALYTICS_WEB_HOST='127.0.0.1',HOMELAB_ANALYTICS_WEB_PORT='18744',HOMELAB_ANALYTICS_API_BASE_URL='http://127.0.0.1:18743',PATH='/projects/dev/homelab-analytics/.tooling/node-v20.20.1-linux-x64/bin:/usr/bin:/bin')
os.environ.clear(); os.environ.update(env); os.chdir(S); sys.path.insert(0,str(S))
from packages.storage.ingestion_config import IngestionConfigRepository, SourceAssetCreate
from packages.storage.ingestion_catalog import SourceFreshnessConfigCreate
from tests.control_plane_test_support import seed_source_asset_graph
repo=IngestionConfigRepository(data/'config.db'); seed_source_asset_graph(repo,include_schedule=False,include_lineage=False,include_audit=False)
for id,name,enabled in [('bank_partner_savings','Bank Partner Savings',True),('bank_partner_disabled','Bank Partner Disabled',False)]:
 repo.create_source_asset(SourceAssetCreate(source_asset_id=id,name=name,source_system_id='bank_partner_export',dataset_contract_id='household_account_transactions_v1',column_mapping_id='bank_partner_export_v1',transformation_package_id='builtin_account_transactions',asset_type='dataset',enabled=enabled))
repo.create_source_freshness_config(SourceFreshnessConfigCreate(source_asset_id='bank_partner_transactions',acquisition_mode='manual_export',expected_frequency='ad_hoc',coverage_kind='rolling_period',due_day_of_month=None,expected_window_days=5,freshness_sla_days=40,sensitivity_class='financial',reminder_channel='dashboard',requires_human_action=True))
py=sys.executable
cmd=[py,'-m','apps.worker.main','create-local-admin-user','bootstrap-admin','bootstrap-pass-123']
r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True); (D/'admin-create.log').write_text(r.stdout); print('admin creation',r.returncode,flush=True); assert r.returncode==0
front=S/'apps/web/frontend'; stand=front/'.next/standalone'; shutil.copytree(front/'.next/static',stand/'.next/static',dirs_exist_ok=True); shutil.copytree(front/'public',stand/'public',dirs_exist_ok=True)
processes=[]
def start(name,cmd):
 f=open(D/(name+'.log'),'wb'); p=subprocess.Popen(cmd,env=env,cwd=S,stdout=f,stderr=subprocess.STDOUT,start_new_session=True); processes.append((name,p,f)); print('owned process',name,p.pid,flush=True); return p
def wait(url,p):
 import httpx
 for i in range(100):
  if p.poll() is not None: raise RuntimeError('process exited '+str(p.returncode))
  try:
   httpx.get(url,timeout=1); return
  except httpx.TransportError: time.sleep(.2)
 raise RuntimeError('startup unavailable '+url)
try:
 import httpx
 api=start('api',[py,'-m','apps.api.main']); wait('http://127.0.0.1:18743/health',api)
 web=start('web',[py,'-m','apps.web.main']); wait('http://127.0.0.1:18744/login',web)
 c=httpx.Client(base_url='http://127.0.0.1:18743',timeout=30)
 def call(method,path,**kw):
  r=c.request(method,path,**kw); print(method,path,r.status_code,r.text[:2000],flush=True); return r
 r=call('POST','/auth/login',json={'username':'bootstrap-admin','password':'bootstrap-pass-123'}); assert r.status_code==200
 csrf=c.cookies.get('homelab_analytics_csrf'); assert csrf; c.headers['x-csrf-token']=csrf
 for role in ['operator','reader']:
  r=call('POST','/auth/users',json={'username':'bootstrap-'+role,'password':'bootstrap-pass-123','role':role}); assert r.status_code==201
 r=call('GET','/control/source-freshness'); assert r.status_code==200
 for role in ['operator','reader']:
  q=httpx.Client(base_url='http://127.0.0.1:18743'); assert q.post('/auth/login',json={'username':'bootstrap-'+role,'password':'bootstrap-pass-123'}).status_code==200
  r=q.get('/control/source-freshness'); print(role,'freshness',r.status_code,flush=True); assert r.status_code==403
 fixture=(S/'tests/fixtures/account_transactions/configured_account_transactions_source.csv')
 if not fixture.exists():
  candidates=list((S/'tests').rglob('configured_account_transactions_source.csv')); assert len(candidates)==1; fixture=candidates[0]
 payload=fixture.read_bytes(); (D/'fixture.csv').write_bytes(payload); print('fixture sha256',hashlib.sha256(payload).hexdigest(),flush=True)
 for path,fields in [('/ingest/dry-run',{'upload_path':'/upload/configured-csv','source_asset_id':'bank_partner_transactions'}),('/ingest/configured-csv',{'source_asset_id':'bank_partner_transactions','source_name':'bootstrap'})]:
  r=call('POST',path,data=fields,files={'file':('fixture.csv',payload,'text/csv')}); assert r.status_code in (200,201)
  if path.endswith('configured-csv'): run=r.json()['run']['run_id']; detail=call('GET','/runs/'+run); assert detail.status_code==200; print('RUN DETAIL',detail.text,flush=True)
 r=call('GET','/control/source-freshness'); print('AFTER',r.text,flush=True)
 print('API POSITIVE CONTROLS FINISHED',flush=True)
except Exception:
 traceback.print_exc(); raise
finally:
 for name,p,f in reversed(processes):
  try: os.killpg(p.pid,signal.SIGTERM); p.wait(timeout=10)
  except ProcessLookupError: pass
  except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); p.wait()
  f.close(); print('cleanup',name,p.pid,p.returncode,flush=True)
