import os,sys,pathlib,subprocess,signal,time,json,hashlib,traceback,io,csv
D=pathlib.Path('/tmp/hla-inline-upload-acceptance-bootstrap-20261115'); S=D/'source'; env={k:v for k,v in os.environ.items() if not (k.startswith('HOMELAB_ANALYTICS_') or any(x in k.upper() for x in ('TOKEN','SECRET','PASSWORD','CREDENTIAL','KUBECONFIG','DATABASE_URL')))}; env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(S),HOMELAB_ANALYTICS_DATA_DIR=str(D/'data'),HOMELAB_ANALYTICS_IDENTITY_MODE='local',HOMELAB_ANALYTICS_SESSION_SECRET='bootstrap-synthetic-secret-01234567890123456789',HOMELAB_ANALYTICS_API_HOST='127.0.0.1',HOMELAB_ANALYTICS_API_PORT='18743',HOMELAB_ANALYTICS_WEB_HOST='127.0.0.1',HOMELAB_ANALYTICS_WEB_PORT='18744',HOMELAB_ANALYTICS_API_BASE_URL='http://127.0.0.1:18743',PATH='/projects/dev/homelab-analytics/.tooling/node-v20.20.1-linux-x64/bin:/usr/bin:/bin'); os.chdir(S);sys.path.insert(0,str(S))
import httpx,openpyxl
ps=[]
def start(name,cmd):
 f=open(D/(name+'-followup.log'),'wb'); p=subprocess.Popen(cmd,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);ps.append((name,p,f));print('owned process',name,p.pid,flush=True);return p
def wait(url,p):
 for _ in range(100):
  if p.poll() is not None: raise RuntimeError('exit '+str(p.returncode))
  try: httpx.get(url,timeout=1);return
  except httpx.TransportError:time.sleep(.2)
 raise RuntimeError('unavailable '+url)
try:
 a=start('api',[sys.executable,'-m','apps.api.main']); wait('http://127.0.0.1:18743/health',a); w=start('web',[sys.executable,'-m','apps.web.main']);wait('http://127.0.0.1:18744/login',w)
 cmd=['docker','run','--rm','--label','hla.bootstrap=inline-20261115','--network','host','-v',str(D)+':/work:ro','sha256:b0ab6f3cb99aa7803adbc14d9027ec1785fc6e433b97e134e0f8fe61683b6b53','node','/work/browser.cjs']; print('BROWSER COMMAND',cmd,flush=True);r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120);(D/'browser-r3.log').write_text(r.stdout);print('browser exit',r.returncode,flush=True);assert r.returncode==0
except Exception:traceback.print_exc();raise
finally:
 for name,p,f in reversed(ps):
  try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
  except ProcessLookupError:pass
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  f.close();print('cleanup',name,p.pid,p.returncode,flush=True)
