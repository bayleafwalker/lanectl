import os, sys, subprocess, time, socket, signal, json, pathlib, shutil, hashlib, traceback
D=pathlib.Path('/tmp/hla-inline-upload-acceptance-bootstrap-20261115'); S=D/'source'; data=D/'data'; data.mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not (k.startswith('HOMELAB_ANALYTICS_') or any(x in k.upper() for x in ('TOKEN','SECRET','PASSWORD','CREDENTIAL','KUBECONFIG','DATABASE_URL')))}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(S),HOMELAB_ANALYTICS_DATA_DIR=str(data),HOMELAB_ANALYTICS_IDENTITY_MODE='local',HOMELAB_ANALYTICS_SESSION_SECRET='bootstrap-synthetic-secret-01234567890123456789',HOMELAB_ANALYTICS_API_HOST='127.0.0.1',HOMELAB_ANALYTICS_API_PORT='18743',HOMELAB_ANALYTICS_WEB_HOST='127.0.0.1',HOMELAB_ANALYTICS_WEB_PORT='18744',HOMELAB_ANALYTICS_API_BASE_URL='http://127.0.0.1:18743',PATH='/projects/dev/homelab-analytics/.tooling/node-v20.20.1-linux-x64/bin:/usr/bin:/bin')
os.environ.clear(); os.environ.update(env); os.chdir(S); sys.path.insert(0,str(S))
from packages.storage.ingestion_config import IngestionConfigRepository, SourceAssetCreate
from packages.storage.ingestion_catalog import SourceFreshnessConfigCreate
from tests.control_plane_test_support import seed_source_asset_graph
repo=IngestionConfigRepository(data/'config.db'); seed_source_asset_graph(repo,include_schedule=False,include_lineage=False,include_audit=False)
for id,name,enabled in [('bank_partner_savings','Bank Partner Savings',True),('bank_partner_disabled','Bank Partner Disabled',False)]:
 repo.create_source_asset(SourceAssetCreate(source_asset_id=id,name=name,source_system_id='bank_partner_export',dataset_contract_id='household_account_transactions_v1',column_mapping_id='bank_partner_export_v1',transformation_package_id='builtin_account_transactions',asset_type='dataset',enabled=enabled))
repo.create_source_freshness_config(SourceFreshnessConfigCreate(source_asset_id='bank_partner_transactions',acquisition_mode='manual_export',expected_frequency='ad_hoc',coverage_kind='rolling_period',due_day_of_month=None,expected_window_days=5,freshness_sla_days=40,sensitivity_class='financial',reminder_channel='dashboard',requires_human_action=True))
py=sys.executable
cmd=[py,'-m','apps.worker.main','create-local-admin-user','bootstrap-admin','bootstrap-pass-123']
r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True); (D/'admin-create.log').write_text(r.stdout); print('admin creation',r.returncode,flush=True); assert r.returncode==0

processes=[]
def start(name,cmd):
 f=open(D/(name+'.log'),'wb'); p=subprocess.Popen(cmd,env=env,cwd=S,stdout=f,stderr=subprocess.STDOUT,start_new_session=True); processes.append((name,p,f)); print('owned process',name,p.pid,flush=True); return p
def wait(url,p):
 import httpx
 for i in range(100):
  if p.poll() is not None: raise RuntimeError('process exited '+str(p.returncode))
  try:
   httpx.get(url,timeout=1); return
  except httpx.TransportError: time.sleep(.2)
 raise RuntimeError('startup unavailable '+url)
try:
 import httpx
 api=start('api',[py,'-m','apps.api.main']); wait('http://127.0.0.1:18743/health',api)

 c=httpx.Client(base_url='http://127.0.0.1:18743',timeout=30)
 def call(method,path,**kw):
  r=c.request(method,path,**kw); print(method,path,r.status_code,r.text[:2000],flush=True); return r
 r=call('POST','/auth/login',json={'username':'bootstrap-admin','password':'bootstrap-pass-123'}); assert r.status_code==200
 csrf=c.cookies.get('homelab_analytics_csrf'); assert csrf; c.headers['x-csrf-token']=csrf
 fixture=(D/'fixture.csv').read_bytes(); landed=call('POST','/ingest/configured-csv',data={'source_asset_id':'bank_partner_transactions','source_name':'population-control'},files={'file':('fixture.csv',fixture,'text/csv')}); assert landed.status_code==201; run_id=landed.json()['run']['run_id']
 before=call('GET','/runs?limit=200'); assert before.status_code==200; before_body=before.json(); print('RUN POPULATION BEFORE',json.dumps(before_body),flush=True); assert run_id in json.dumps(before_body); assert len(before_body['runs']) == 1
 bad=b'booking_date,account_number,payee\n2026-01-01,foo,bar\n'; r=call('POST','/ingest/dry-run',data={'upload_path':'/upload/configured-csv','source_asset_id':'bank_partner_transactions'},files={'file':('bad.csv',bad,'text/csv')}); assert r.status_code==200 and not r.json()['preview']['ready']
 after=call('GET','/runs?limit=200'); assert after.status_code==200; print('RUN POPULATION AFTER',json.dumps(after.json()),flush=True); assert before_body==after.json(); print('FULL SINGLE-RUN POPULATION UNCHANGED',flush=True)
 print('API POSITIVE CONTROLS FINISHED',flush=True)
except Exception:
 traceback.print_exc(); raise
finally:
 for name,p,f in reversed(processes):
  try: os.killpg(p.pid,signal.SIGTERM); p.wait(timeout=10)
  except ProcessLookupError: pass
  except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); p.wait()
  f.close(); print('cleanup',name,p.pid,p.returncode,flush=True)
